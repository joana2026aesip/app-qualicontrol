import{U as a,C as n}from"./mermaid.core-C-7N2Zve.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
